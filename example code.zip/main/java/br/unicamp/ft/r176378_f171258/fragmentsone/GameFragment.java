package br.unicamp.ft.r176378_f171258.fragmentsone;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;


public class GameFragment extends Fragment {
    final ArrayList<Aluno> alunos = new ArrayList(Arrays.asList(Alunos.alunos));
    Random random;
    private int position;

    // TODO: Rename and change types of parameters
    private int numberOfErrors = 0;
    View.OnClickListener btnListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Button b = (Button) v;
            int idade = 0;
            String buttonText = b.getText().toString();
            try {
                idade = Integer.parseInt(buttonText);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
            checkIdadeResult(idade);
        }
    };


    public GameFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_game, container, false);
    }

    private void checkIdadeResult(int idade) {
        if (idade == alunos.get(position).getIdade()) {
            getView().findViewById(R.id.game_error).setAlpha(0);
            Toast.makeText(getContext(), "acerto", Toast.LENGTH_SHORT).show();
            numberOfErrors = 0;
            int maxNumber = alunos.size() - 1;
            position = random.nextInt(maxNumber);
            ImageView imageView;
            imageView = getView().findViewById(R.id.image_game);
            imageView.setImageResource(alunos.get(position).getFoto());

        } else {
            getView().findViewById(R.id.game_error).setAlpha(1);
            Toast.makeText(getContext(), "erro", Toast.LENGTH_SHORT).show();
            numberOfErrors = numberOfErrors + 1;
            if (numberOfErrors >= 3) {
                numberOfErrors = 0;
                FragmentManager fragmentManager2 = getFragmentManager();
                try {
                    FragmentTransaction ftrans = fragmentManager2.beginTransaction();
                    TelaBiografia biofrafiaFrame = new TelaBiografia();
                    biofrafiaFrame.setPosition(position);
                    ftrans.replace(R.id.containerOne, biofrafiaFrame, "biografiaFrame");
                    ftrans.addToBackStack("biografiaFrame");
                    ftrans.commit();
                } catch (NullPointerException e) {
                    e.printStackTrace();
                }

            }
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //setting an random student
        random = new Random();
        int maxNumber = alunos.size() - 1;
        position = random.nextInt(maxNumber);
        ImageView imageView;
        imageView = getView().findViewById(R.id.image_game);
        imageView.setImageResource(alunos.get(position).getFoto());

        //Declaring, instantiating and setting listeners for fragment buttons
        Button btnIdade19 = getActivity().findViewById(R.id.game_idade_19);
        btnIdade19.setOnClickListener(btnListener);
        Button btnIdade20 = getActivity().findViewById(R.id.game_idade_20);
        btnIdade20.setOnClickListener(btnListener);
        Button btnIdade21 = getActivity().findViewById(R.id.game_idade_21);
        btnIdade21.setOnClickListener(btnListener);
        Button btnIdade22 = getActivity().findViewById(R.id.game_idade_22);
        btnIdade22.setOnClickListener(btnListener);
        Button btnIdade23 = getActivity().findViewById(R.id.game_idade_23);
        btnIdade23.setOnClickListener(btnListener);
        Button btnIdade24 = getActivity().findViewById(R.id.game_idade_24);
        btnIdade24.setOnClickListener(btnListener);
        Button btnIdade25 = getActivity().findViewById(R.id.game_idade_25);
        btnIdade25.setOnClickListener(btnListener);
        Button btnIdade26 = getActivity().findViewById(R.id.game_idade_26);
        btnIdade26.setOnClickListener(btnListener);
        Button btnIdade27 = getActivity().findViewById(R.id.game_idade_27);
        btnIdade27.setOnClickListener(btnListener);
    }
}
