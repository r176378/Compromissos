package br.unicamp.ft.r176378_f171258.fragmentsone;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;


/**
 * A simple {@link Fragment} subclass.
 */
public class TelaBiografiasList extends Fragment {

    private RecyclerView mRecyclerView;
    private BiografiaListAdapter mAdapter;

    public TelaBiografiasList() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_my_first, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mRecyclerView = getView().findViewById(R.id.alunosRecycler);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mAdapter = new BiografiaListAdapter(new ArrayList(Arrays.asList(Alunos.alunos)));
        mAdapter.setMyOnItemClickListener(new BiografiaListAdapter.MyOnItemClickListener() {
            @Override
            public void myOnItemClick(String nome) {
                Toast.makeText(getContext(), "Hello toast!!", Toast.LENGTH_LONG).show();

            }
        });

        mAdapter.setMyOnLongClickListener(new BiografiaListAdapter.MyOnLongClickListener() {
            @Override
            public void myOnLongClick(Integer position) {
                FragmentManager fragmentManager2 = getFragmentManager();
                FragmentTransaction ftrans = fragmentManager2.beginTransaction();
                TelaBiografia frameBiografia = new TelaBiografia();
                frameBiografia.setPosition(position);
                ftrans.replace(R.id.containerOne, frameBiografia, "frameBiografia");
                ftrans.addToBackStack("frameBiografia");
                ftrans.commit();
            }
        });
        mRecyclerView.setAdapter(mAdapter);
    }
}
