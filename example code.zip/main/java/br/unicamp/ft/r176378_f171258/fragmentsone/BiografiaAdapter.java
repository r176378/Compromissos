package br.unicamp.ft.r176378_f171258.fragmentsone;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BiografiaAdapter extends RecyclerView.Adapter {

    private Aluno aluno;
    private br.unicamp.ft.r176378_f171258.fragmentsone.BiografiaAdapter.MyOnItemClickListener myOnItemClickListener;

    public BiografiaAdapter(Aluno aluno) {
        this.aluno = aluno;
        //    alunos.add(mAlunos.get(0));
    }

    public void setMyOnItemClickListener(br.unicamp.ft.r176378_f171258.fragmentsone.BiografiaAdapter.MyOnItemClickListener myOnItemClickListener) {
        this.myOnItemClickListener = myOnItemClickListener;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.fragment_biografia, parent, false);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (myOnItemClickListener != null) {
                    TextView txt = view.findViewById(R.id.name);
                    myOnItemClickListener.myOnItemClick(txt.getText().toString());
                }
            }
        });
        return new br.unicamp.ft.r176378_f171258.fragmentsone.BiografiaAdapter.MyFirstViewHolder(v);
    }

    private void removeData(Aluno aluno) {

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        final Aluno aluno = this.aluno;
        ((br.unicamp.ft.r176378_f171258.fragmentsone.BiografiaAdapter.MyFirstViewHolder) holder).bind(aluno);
    }

    @Override
    public int getItemCount() {
        return 1;
    }

    public interface MyOnItemClickListener {
        void myOnItemClick(String nome);
    }

    class MyFirstViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout container;
        private ImageView imageView;
        private TextView name;
        private TextView ra;
        private TextView cv;
        private TextView idade;

        public MyFirstViewHolder(View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.container_biografia);
            imageView = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);
            ra = itemView.findViewById(R.id.ra);
            cv = itemView.findViewById(R.id.cv);
            idade = itemView.findViewById(R.id.idade);
            cv.setMaxLines(20);
        }

        public void bind(final Aluno aluno) {
            imageView.setImageResource(aluno.getFoto());
            name.setText(aluno.getNome());
            ra.setText(aluno.getRa());
            cv.setText(Html.fromHtml(aluno.getMiniCV()));
            idade.setText((String.valueOf(aluno.getIdade())) + " anos");
            //  cv.setMaxLines(25);


        }
    }

}


