package br.unicamp.ft.r176378_f171258.fragmentsone;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class BiografiaListAdapter extends RecyclerView.Adapter {
    private ArrayList<Aluno> alunos;
    private MyOnItemClickListener myOnItemClickListener;
    private MyOnLongClickListener myOnLongClickListener;

    BiografiaListAdapter(ArrayList<Aluno> alunos) {
        this.alunos = alunos;
    }

    public void setMyOnLongClickListener(MyOnLongClickListener myOnLongClickListener) {
        this.myOnLongClickListener = myOnLongClickListener;
    }

    public void setMyOnItemClickListener(MyOnItemClickListener myOnItemClickListener) {
        this.myOnItemClickListener = myOnItemClickListener;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.fragment_biografia, parent, false);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (myOnItemClickListener != null) {
                    TextView txt = view.findViewById(R.id.name);
                    myOnItemClickListener.myOnItemClick(txt.getText().toString());
                }
            }
        });
        return new MyFirstViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {
        ((MyFirstViewHolder) holder).container.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (myOnLongClickListener != null) {
                    myOnLongClickListener.myOnLongClick(position);
                }
                return true;
            }
        });
        final Aluno aluno = alunos.get(position);
        ((MyFirstViewHolder) holder).bind(aluno);
    }

    @Override
    public int getItemCount() {
        return alunos.size();
    }

    public interface MyOnItemClickListener {
        void myOnItemClick(String nome);
    }

    public interface MyOnLongClickListener {
        void myOnLongClick(Integer position);
    }

    class MyFirstViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout container;
        private ImageView imageView;
        private TextView name;
        private TextView ra;
        private TextView cv;

        MyFirstViewHolder(View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.container_biografia);
            imageView = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);
            ra = itemView.findViewById(R.id.ra);
            cv = itemView.findViewById(R.id.cv);
        }

        void bind(final Aluno aluno) {
            imageView.setImageResource(aluno.getFoto());
            name.setText(aluno.getNome());
            ra.setText(aluno.getRa());
            cv.setText(Html.fromHtml(aluno.getMiniCV()));
        }
    }
}
