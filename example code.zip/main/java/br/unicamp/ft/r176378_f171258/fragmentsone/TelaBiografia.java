package br.unicamp.ft.r176378_f171258.fragmentsone;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;


public class TelaBiografia extends Fragment {
    final ArrayList<Aluno> alunos = new ArrayList(Arrays.asList(Alunos.alunos));
    private RecyclerView mRecyclerView;
    private BiografiaAdapter mAdapter;
    private int position;
    View.OnClickListener btnNextListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (position >= (alunos.size() - 1)) {
                position = 0;
            } else {
                position++;
            }
            ImageView imageView;
            TextView name;
            TextView ra;
            TextView cv;
            TextView idade;
            imageView = getView().findViewById(R.id.image);
            name = getView().findViewById(R.id.name);
            ra = getView().findViewById(R.id.ra);
            cv = getView().findViewById(R.id.cv);
            idade = getView().findViewById(R.id.idade);
            imageView.setImageResource(alunos.get(position).getFoto());
            name.setText(alunos.get(position).getNome());
            ra.setText(alunos.get(position).getRa());
            cv.setText(Html.fromHtml(alunos.get(position).getMiniCV()));
            idade.setText(String.valueOf(alunos.get(position).getIdade()));
            cv.setMaxLines(30);
        }
    };
    private Button ButtonNext;

    public TelaBiografia() {
        // Required empty public constructor
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tela_biografia, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRecyclerView = getView().findViewById(R.id.biografiaRecycler);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mAdapter = new BiografiaAdapter(alunos.get(position));
        mRecyclerView.setAdapter(mAdapter);
        getActivity().findViewById(R.id.nextBioButton).setOnClickListener(btnNextListener);
    }
}
