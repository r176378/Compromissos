package br.unicamp.ft.r176378_f171258.fragmentsone;

public class Aluno {

    private String nome;
    private String ra;
    private int foto;
    private String miniCV;
    private int idade;
    private double autura;
    private int fotoTime;

    Aluno(String nome, String ra, int foto, String miniCV, double altura, int idade, int fotoTime) {
        this.nome = nome;
        this.ra = ra;
        this.foto = foto;
        this.miniCV = miniCV;
        this.idade = idade;
        this.autura = altura;
        this.fotoTime = fotoTime;


    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public double getAutura() {
        return autura;
    }

    public void setAutura(double autura) {
        this.autura = autura;
    }

    public int getFotoTime() {
        return fotoTime;
    }

    public void setFotoTime(int fotoTime) {
        this.fotoTime = fotoTime;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRa() {
        return ra;
    }

    public void setRa(String ra) {
        this.ra = ra;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public String getMiniCV() {
        return miniCV;
    }

    public void setMiniCV(String miniCV) {
        this.miniCV = miniCV;
    }
}